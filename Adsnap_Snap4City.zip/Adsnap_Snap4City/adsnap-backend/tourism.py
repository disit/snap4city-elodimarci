import pandas as pd


def tourist_attractions():
    df = pd.read_csv("data/tourist-attractions-snapped.csv", header=0)

    return df.sample(n=1000).iloc[:, 1:].to_dict('records')
