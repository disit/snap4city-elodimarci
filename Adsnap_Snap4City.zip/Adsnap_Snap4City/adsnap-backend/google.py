import json

import googlemaps

gmaps = googlemaps.Client(key='AIzaSyD457y8tjzxwFf1YCEHv2bwTWyqN7aHocM')


def nearest_road(coordinates):
    if len(coordinates) is 0:
        print('zero length')
        return []

    max_size = 100

    if len(coordinates) < max_size:
        result = gmaps.nearest_roads(points=coordinates)
        return [{"lat": r['location']['latitude'], "lng": r['location']['longitude']} for r in result]
    else:
        chunks = [coordinates[i:i + max_size] for i in range(0, len(coordinates), max_size)]
        all_points = []

        for chunk in chunks:
            result = gmaps.nearest_roads(points=chunk)
            points = [{"lat": r['location']['latitude'], "lng": r['location']['longitude']} for r in result]
            all_points += points

        return all_points
