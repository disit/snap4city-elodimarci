import random
import math
from math import radians, cos, sin, asin, sqrt
from google import nearest_road


def get_random_coordinate(x, y, r):
    circle_r = r
    circle_x = x
    circle_y = y

    alpha = 2 * math.pi * random.random()
    # alpha = random.choice([1, -1, 0.5, -0.5]) * math.pi + (random.choice([1, -1]) * random.random() / 10)

    r = circle_r * math.sqrt(random.random())
    x = r * math.cos(alpha) + circle_x
    y = r * math.sin(alpha) + circle_y

    return x, y


def get_random_coordinates(x, y, r, n, snap=True):
    result = []

    for _ in range(n):
        a, b = get_random_coordinate(x, y, r)
        result.append({"lat": a, "lng": b})

    if snap:
        return nearest_road(result)

    return result


def filter_df_to_helsinki(df):
    return df[(60.188762 > df.lat) & (df.lat > 60.146566) & (24.980417 > df.lng) & (df.lng > 24.898034)]


def haversine(lng1, lat1, lng2, lat2):
    lng1, lat1, lng2, lat2 = map(radians, [lng1, lat1, lng2, lat2])

    dlon = lng2 - lng1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371
    return c * r


def haversine_coordinates(c1, c2):
    return haversine(c1['lng', c1['lat'], c2['lng'], c2['lat']])

