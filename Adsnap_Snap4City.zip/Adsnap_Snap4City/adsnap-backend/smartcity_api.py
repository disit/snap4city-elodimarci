import requests
from urllib.parse import urlencode
import pprint

from utils import augment_coordinates

helsinki_boundaries = [60.146566, 24.898034, 60.188762,24.980417]
smart_city_base_url = "https://helsinki.snap4city.org/ServiceMap/api/v1/?"


def get_coordinates(feature):
    return {'lat': feature['geometry']['coordinates'][1], 'lng': feature['geometry']['coordinates'][0]}


def create_smart_city_url(categories, max_results = 10):
    query_params = {
        'categories': ';'.join(categories),
        'selection': ';'.join(str(s) for s in helsinki_boundaries),
        'maxResults': 10000,
        'fomat': 'json'
    }

    url = smart_city_base_url + urlencode(query_params)
    print(url)
    return url

def get_bus_stops():
    categories = ['BusStop']
    url = create_smart_city_url(categories=categories, max_results=280)

    response = requests.get(url).json()

    return [get_coordinates(stop) for stop in response['BusStops']['features']]


def get_shopping_centres():
    categories = ['Shopping_centre']
    url = create_smart_city_url(categories=categories, max_results=280)

    response = requests.get(url).json()

    return [get_coordinates(center) for center in response['Services']['features']]


def get_hsl_ticket_sale():
    categories = ['Ticket_sale']
    url = create_smart_city_url(categories=categories, max_results=280)

    response = requests.get(url).json()

    return [get_coordinates(center) for center in response['Services']['features']]


def get_hotels():
    categories = ['Hotel']
    url = create_smart_city_url(categories=categories, max_results=280)

    response = requests.get(url).json()

    return [get_coordinates(center) for center in response['Services']['features']]


def get_other_accommodations():
    categories = ['Other_accommodation']
    url = create_smart_city_url(categories=categories, max_results=280)

    response = requests.get(url).json()

    return [get_coordinates(center) for center in response['Services']['features']]


def get_food_services():
    categories = ['Canteens_and_food_service']
    url = create_smart_city_url(categories=categories, max_results=280)

    response = requests.get(url).json()

    return [get_coordinates(center) for center in response['Services']['features']]


def get_combined_services(categories):
    url = create_smart_city_url(categories=categories, max_results=10000)
    response = requests.get(url).json()

    bus_stops = []
    other_services = []

    if 'BusStop' in categories:
        bus_stops = [get_coordinates(stop) for stop in response['BusStops']['features']]

    if 'Services' in response:
        other_services = [get_coordinates(center) for center in response['Services']['features']]

    all_points =  bus_stops + other_services

    result = []

    for point in all_points:
        closeby = augment_coordinates(point['lat'], point['lng'], 0.005, 15)
        result += closeby

    return result

get_food_services()