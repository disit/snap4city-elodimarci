import datetime
import random

import pandas as pd
import json


def population(min_age, max_age):
    df = pd.read_csv("data/population.csv", header=0)

    districts = df[(df.minAge > min_age) & (df.maxAge <= max_age)].groupby(['district']).sum()

    # print(districts)

    max_population = districts['population'].max()
    max_points = 500
    # print(max_points)

    points = []

    for name, district in districts.iterrows():
        relative_population = district.population / max_population  # between 0 and 1
        number_of_points = int(max_points * relative_population)

        with open('data/districts.json', 'r') as f:
            districts_data = json.load(f)
            district_data = [x for x in districts_data if x["name"] == name][0]
            geometry = district_data["address"][0]["geometry"]

            if "bounds" in geometry:
                bounds = geometry["bounds"]
                ne_lat = bounds["northeast"]["lat"]
                ne_lng = bounds["northeast"]["lng"]
                sw_lat = bounds["southwest"]["lat"]
                sw_lng = bounds["southwest"]["lng"]

            else:
                viewport = district_data["address"][0]["geometry"]["viewport"]
                ne_lat = viewport["northeast"]["lat"]
                ne_lng = viewport["northeast"]["lng"]
                sw_lat = viewport["southwest"]["lat"]
                sw_lng = viewport["southwest"]["lng"]

            random.seed(1)
            for _ in range(number_of_points):
                lat = random.uniform(sw_lat, ne_lat)
                lng = random.uniform(sw_lng, ne_lng)

                points.append({"lat": lat, "lng": lng})

    return points
