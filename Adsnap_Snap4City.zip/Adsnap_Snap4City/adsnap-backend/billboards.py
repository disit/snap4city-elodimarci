import random
import json
import pandas as pd
from scipy.spatial.distance import cdist
import numpy as np


def load_billboards():
    with open('data/billboards.json') as f:
        data = json.load(f)

        for item in data:
            item["active"] = random.choice([True, False])

        return data


billboards = load_billboards()
treshhold = 0.005


def get_positions_around_billboard(positions, number_of_billboards):
    print('# billboards: ', len(billboards), '# positions: ', len(positions))

    positions_df = pd.DataFrame(positions)
    billboards_df = pd.DataFrame(billboards)

    distance_matrix = cdist(billboards_df.iloc[:, 3:5], positions_df.iloc[:, 0:], )
    position_count = [(row <= treshhold).sum() for row in distance_matrix]
    billboards_df['views_per_day'] = position_count

    if number_of_billboards:
        pc_sorted = np.sort(position_count)
        min_value = pc_sorted[-min(len(pc_sorted - 1), number_of_billboards)]
        billboards_df['active'] = billboards_df.apply(lambda row: row['views_per_day'] >= min_value, axis=1)

    reach = billboards_df[billboards_df['active']]['views_per_day'].sum()

    days = [0.219150869629536, 0.21966510985721, 0.143406101847743, 0.184425565488141, 0.0770092351909381, 0.0897912748226576, 0.066551843163775 ]
    weeks = [1.1, 0.85, 0.9, 1, 1.2]

    daily_score = []

    for w in weeks:
        for d in days:
            daily_score.append(w*d)

    daily_score = daily_score[:31]


    monthly_reach = [int(reach * d * random.uniform(0.9, 1.1)) for d in daily_score]
    active_billboards = len(billboards_df[billboards_df['active']].index)

    return billboards_df, monthly_reach, reach, active_billboards


def get_data_for_billboards(requested_billboards):
    billboards_df = pd.DataFrame(requested_billboards)

    reach = billboards_df[billboards_df['active']]['views_per_day'].sum()

    days = [0.219150869629536, 0.21966510985721, 0.143406101847743, 0.184425565488141, 0.0770092351909381,
            0.0897912748226576, 0.066551843163775]
    weeks = [1.1, 0.85, 0.9, 1, 1.2]

    daily_score = []

    for w in weeks:
        for d in days:
            daily_score.append(w * d)

    daily_score = daily_score[:31]

    monthly_reach = [int(reach * d * random.uniform(0.9, 1.1)) for d in daily_score]
    active_billboards = len(billboards_df[billboards_df['active']].index)

    return billboards_df, monthly_reach, reach, active_billboards
