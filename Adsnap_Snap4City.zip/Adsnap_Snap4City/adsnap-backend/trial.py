import csv
import random

import pandas as pd
import json

# minAge = 24
# maxAge = 35
#
# df = pd.read_csv("data/population.csv", header=0)
#
# districts = df[(df.minAge > minAge) & (df.maxAge <= maxAge)].groupby(['district']).sum()
#
# maxPopulation = 4459
# maxPoints = 50
#
# for name, district in districts.iterrows():
#     relativePopulation = district.population / maxPopulation  # between 0 and 1
#     numberOfPoints = int(maxPoints * relativePopulation)
#
#     with open('data/districts.json', 'r') as f:
#         districtsData = json.load(f)
#         districtData = [x for x in districtsData if x["name"] == name][0]
#
#         bounds = districtData["address"]["bounds"]
#         ne_lat = bounds["northeast"]["lat"]
#         ne_lng = bounds["northeast"]["lng"]
#         sw_lat = bounds["southwest"]["lat"]
#         sw_lng = bounds["southwest"]["lng"]
#
#         for _ in range(numberOfPoints):
#             lat = random.uniform(sw_lat, ne_lat)
#             lng = random.uniform(sw_lng, ne_lng)


# from transport_data import hsl_sales_points, city_bikes
# from google import nearest_road
import requests
import xml.etree.ElementTree as ET


from tourism import tourist_attractions

# data = hsl_sales_points()
# nearest = nearest_road(data)
# df = pd.DataFrame(nearest)
#
# df.to_csv('data/hsl-sales-points-snapped.csv', sep=',')

#
# print(data)
# with open('data/tourist-attractions-snapped.csv', 'w') as f:
#     csv.writer(f, delimiter=",")

import googlemaps
from datetime import datetime
from utils import  augment_coordinates, filter_df_to_helsinki

# gmaps = googlemaps.Client(key='AIzaSyD457y8tjzxwFf1YCEHv2bwTWyqN7aHocM')
# cars = pd.read_csv("data/cars.csv", header=0)
#
# lat = []
# lng = []
#
# for name, row in cars.iterrows():
#     result = gmaps.geocode(row['name'] + ' Helsinki')
#
#     location = result[0]['geometry']['location']
#     lat.append(location['lat'])
#     lng.append(location['lng'])
#
# cars['lat'] = lat
# cars['lng'] = lng
# cars.to_csv('data/cars.csv', sep=',')

result = []

cars = pd.read_csv("data/cars.csv", header=0)
cars = filter_df_to_helsinki(cars)

for index, car in cars.iterrows():
    closeby = augment_coordinates(car['lat'], car['lng'], 0.01, int(car['count'] * 1))
    result += closeby


pd.DataFrame(result).to_csv('data/cars-extended.csv', sep=',')

print(result)
print(len(result))
