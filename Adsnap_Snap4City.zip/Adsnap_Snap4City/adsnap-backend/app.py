from flask import Flask, jsonify, request
from flask_cors import CORS
import datetime
from transport_data import city_bikes, hsl_sales_points, traffic
from population import population
from tourism import tourist_attractions
from google import nearest_road
from billboards import get_positions_around_billboard, get_data_for_billboards

app = Flask(__name__)
CORS(app)


@app.route('/')
def hello_world():
    return 'Hello World!'


transport_car = 'CAR'
transport_public = 'PUBLIC_TRANSPORT'
transport_cycling= 'CYCLING'

occupation_resident = 'RESIDENT'
occupation_tourist = 'TOURIST'

@app.route('/heatmap-data', methods=['POST'])
def heatmap_data():
    print('Request start: ', datetime.datetime.now())
    params = request.json

    min_age = params['minAge']
    max_age = params['maxAge']
    transport = params['transportType']
    occupation = params['occupationType']
    number_of_billboards = params.get('numberOfBillboards', 10)
    requested_positions = params.get('positions', None)
    requested_billboards = params.get('billboards', None)

    if requested_billboards and requested_positions:
        positions = requested_positions
        billboards, monthly_reach, total_reach, active_billboards = get_data_for_billboards(requested_billboards=requested_billboards)

    else:
        combined_points = []

        if transport == transport_cycling:
            combined_points += city_bikes()
        elif transport == transport_public:
            combined_points += hsl_sales_points()
        elif transport == transport_car:
            combined_points += traffic()

        if occupation == occupation_resident:
            combined_points += nearest_road(population(min_age, max_age))
        elif occupation == occupation_tourist:
            combined_points += tourist_attractions()

        positions = combined_points
        billboards, monthly_reach, total_reach, active_billboards = get_positions_around_billboard(positions,
                                                                                number_of_billboards=number_of_billboards)

    return jsonify({"positions": positions,
                    "billboards": billboards.to_dict('records'),
                    "monthlyReach": monthly_reach,
                    "totalReach": str(total_reach),
                    "activeBillboards": active_billboards
                    })


if __name__ == '__main__':
    app.run(debug=True)
