import pandas as pd
from utils import augment_coordinates
from utils import filter_df_to_helsinki


def city_bikes(load=False):
    if load:
        stations = pd.read_csv("data/city-bike_stations.csv", header=0)
        stations = filter_df_to_helsinki(stations)
        result = []

        for index, station in stations.iterrows():
            closeby = augment_coordinates(station[0], station[1], 0.002, 10)
            result += closeby

    stations = pd.read_csv("data/city-bikes-snapped.csv", header=0)
    return stations.iloc[:, 1:].to_dict('records')


def hsl_sales_points(load=False):
    if load:
        df = pd.read_csv("data/hsl_sales_points.csv", header=0)

        df = filter_df_to_helsinki(df)

        result = []

        for index, station in df.iterrows():
            closeby = augment_coordinates(station[0], station[1], 0.002, 5)
            result += closeby

        return result

    df = pd.read_csv("data/hsl-sales-points-snapped.csv", header=0)
    return df.sample(n=1000).iloc[:, 1:].to_dict('records')


def traffic(load=False):
    if load:
        result = []
        cars = pd.read_csv("data/cars.csv", header=0)
        cars = filter_df_to_helsinki(cars)

        for index, car in cars.iterrows():
            closeby = augment_coordinates(car['lat'], car['lng'], 0.01, int(car['count'] * 1))
            result += closeby

        return result

    df = pd.read_csv("data/cars-extended.csv", header=0)
    return df.iloc[:, 1:].to_dict('records')
