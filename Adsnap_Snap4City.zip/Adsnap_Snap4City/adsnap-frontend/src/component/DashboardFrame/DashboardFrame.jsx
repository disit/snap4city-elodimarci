import React  from 'react';
import { Modal } from 'react-bootstrap';
import Iframe from 'react-iframe'

import snapLogo from './images/snapLogo.png';

const dasboardIds = {
    Hotel: 'MTY1NA',
    Shopping_centre: 'MTY1Mw',
    BusStop: 'MTY1NQ',
    Ticket_sale: 'MTY1Ng',
    Other_accommodation: 'MTY2NA',
    Canteens_and_food_service: 'MTY2NQ'
};

const DashboardFrame = ({ categoryId, name, onClose }) => {
    return (
        <Modal
            show={categoryId !== null}
            aria-labelledby="contained-modal-title-vcenter"
            size="lg"
            onHide={onClose}
        >
            <Modal.Header closeButton={true}>
                {name && name.label} in Helsinki by <img src={snapLogo} style={{width: 90, marginLeft: 10}}/>
            </Modal.Header>
            <Modal.Body>
                <div style={{ height: 600 }}>
                    <Iframe width="730" height="550"
                            url={`https://www.snap4city.org/dashboardSmartCity/view/index.php?iddasboard=${dasboardIds[categoryId]}==&embedPolicy=manual&showHeader=no&autofit=no`} />
                </div>
            </Modal.Body>
        </Modal>
    )
};

export default DashboardFrame;
