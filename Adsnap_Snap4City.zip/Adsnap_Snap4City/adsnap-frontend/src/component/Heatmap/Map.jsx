import React, { Component } from 'react';
import GoogleMapReact from '../GoogleMapReact';
import { BounceLoader } from 'react-spinners';

import styles from './Map.module.sass';
import activeMarker from './images/marker-active.svg';
import disabledMarker from './images/marker-disabled.svg';
import selectedMarker from './images/marker-selected.svg';
import _ from 'lodash';


const BillboardMarker = ({ active, selected, onClickCallback }) => {
    const marker = selected ? selectedMarker : (active ? activeMarker : disabledMarker);

    return (
        <div>
            <img src={marker} className={styles.marker} alt="marker" onClick={() => onClickCallback()} />
            {selected && <BounceLoader sizeUnit={'px'}
                                       size={20}
                                       css={{'marginLeft': -8, 'marginTop': 3}}
                                       color={'#E049E8'} />}
        </div>
    )
};

class HeatMap extends Component {
    static defaultProps = {
        center: {
            lat: 60.168194,
            lng: 24.935809
        },
        zoom: 14
    };


    constructor(props) {
        super(props);

        this.state = {
            markers: [],
            shouldUpdate: false,
            positions: props.positions
        };

        this.handleClick = this.handleClick.bind(this);
    }

    componentDidCatch(e){
        console.log('catch', e)
    }

    componentDidUpdate(prevProps, prevState){
        const {shouldUpdate} = prevState;

        const equals = _.isEqual(this.props.positions, this.state.positions);


        if (!equals){
            this.setState({shouldUpdate: true, positions: this.props.positions})
            setInterval(() =>  this.setState({shouldUpdate: false}), 100)
        }

        else if (equals && shouldUpdate){
            this.setState({shouldUpdate: false})
        }


    }


    handleClick({ x, y, lat, lng, event }) {
        const { markers } = this.state;
        const typeRandom = Math.random();

        this.setState({
            markers: [...markers, {
                lat,
                lng,
                type: typeRandom > 0.8 ? 'BILLBOARD' : 'SOLO_STAND'
            }]
        }, () => console.log(JSON.stringify(this.state.markers)));
    }

    render() {
        const { radius, opacity, billboards, setBillboard, selectedBillboard } = this.props;
        const {shouldUpdate, positions} = this.state;

        return (
            <div className={styles.mapContainer}>
                <GoogleMapReact
                    bootstrapURLKeys={{ key: 'AIzaSyD457y8tjzxwFf1YCEHv2bwTWyqN7aHocM' }}
                    defaultCenter={this.props.center}
                    defaultZoom={this.props.zoom}
                    onClick={this.handleClick}
                    heatmapLibrary={true}
                    updateHeatmap={shouldUpdate}
                    heatmap={{ positions, options: { radius, opacity } }}
                >
                    {billboards.map((item, index) => (
                        <BillboardMarker
                            key={`${item.lat}-${item.lng}`}
                            lat={item.lat}
                            lng={item.lng}
                            active={item.active}
                            selected={index === selectedBillboard}
                            onClickCallback={() => setBillboard(index)}
                        />
                    ))}
                </GoogleMapReact>
            </div>
        );
    }
}

export default HeatMap;
