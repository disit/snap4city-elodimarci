import React, { Component } from 'react';
import { Row, Col, ListGroup, Navbar, ButtonGroup, Button, Modal } from 'react-bootstrap';
import InputRange from 'react-input-range';
import { BounceLoader } from 'react-spinners';
import 'react-input-range/lib/css/index.css';
import _ from 'lodash';
import { Bar, BarChart, XAxis, ResponsiveContainer } from 'recharts'

import Heatmap from '../../component/Heatmap';

import styles from './NewAdPage.module.sass';

import logoIcon from './images/logo.svg';
import soloIcon from './images/solo.svg';
import billboardIcon from './images/billboard.svg';

const runningOnLocalhost = false;
const API_URL = runningOnLocalhost ? 'http://127.0.0.1:5000' : 'https://adsnap-backend.herokuapp.com';


const startDate = new Date('2019-03-01');
const days = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'];

const serialiseData = (data) => data.map((item, index) => {
    const time = new Date();
    time.setDate(startDate.getDate() + index);

    return ({
        value: item,
        time: time.toLocaleDateString('hu-HU'),
        day: days[index % 7]
    })
});

const ActiveBillboardList = ({ billboards, selectBillboard, selectedBillboard }) => {

    return (
        <div className={styles.activeBillboardContainer}>
            <ListGroup>
                {billboards && billboards.map((item, index) => {
                    const { address, type, id, active, views_per_day } = item;

                    if (!active) return null;

                    const image = type === 'BILLBOARD' ? billboardIcon : soloIcon;
                    const typeName = type === 'BILLBOARD' ? 'Billboard' : 'Solo Stand';

                    return (
                        <ListGroup.Item key={id} onClick={() => selectBillboard(index)}
                                        className={styles.billboardRow}
                                        active={index === selectedBillboard}>
                            <img src={image} className={styles.billboardIcon} />
                            <div className={styles.billboardInformation}>
                                <div>{address}</div>
                                <div className={styles.billboardType}>{typeName}</div>
                            </div>
                            <div className={styles.billboardViewContainer}>
                                <div className={styles.billboardViewValue}>{views_per_day}</div>
                                <div className={styles.billboardViewLabel}>monthly view</div>
                            </div>

                        </ListGroup.Item>
                    )
                }).filter(item => item != null)}
            </ListGroup>
        </div>
    )
};

const formatNumber = (number) => {
    if (number > 1000) {
        return `${parseInt(number / 1000)}K`
    }

    return parseInt(number);
};

const CounterWithLabel = ({ value, label, postfix }) => (
    <div className={styles.counterWitLabel}>
        <div className={styles.counterValue}>{postfix} {formatNumber(value)} </div>
        <div className={styles.counterLabel}>{label}</div>
    </div>
);

const renderCustomAxisTick = ({ x, y, payload }) => {
    return (
        <svg x={x} y={y} width={24} height={24} viewBox="0 0 1024 1024" fill="#666">
            <text>{payload.value}</text>
        </svg>
    );
};

const PUBLIC_TRANSPORT = 'PUBLIC_TRANSPORT';
const CAR = 'CAR';
const CYCLING = 'CYCLING';

const RESIDENT = 'RESIDENT';
const TOURIST = 'TOURIST';

class NewAdPage extends Component {
    state = {
        dataLoading: true,
        billboardLoading: true,
        cityBikes: null,
        billboards: null,
        selectedBillboard: null,
        activeBillboards: 0,
        totalReach: 0,
        configuration: {
            minAge: 24,
            maxAge: 45,
            transportType: CAR,
            occupationType: TOURIST,
            numberOfBillboards: 10,
        },
        previousConfiguration: null,
        openedBillboardDetails: null,
        helpModelOpen: true
    };

    constructor(props) {
        super(props);

        this.setBillboard = this.setBillboard.bind(this);
        this.selectBillboard = this.selectBillboard.bind(this);
        this.onTransportChange = this.onTransportChange.bind(this);
        this.onOccupationChange = this.onOccupationChange.bind(this);
        this.refreshData = this.refreshData.bind(this);
        this.onAgeRangeChange = this.onAgeRangeChange.bind(this);
        this.openBillboardDetails = this.openBillboardDetails.bind(this);
    }


    componentDidMount() {
        this.refreshData(false);

        // fetch(`${API_URL}/billboards`)
        //     .then((response) => response.json())
        //     .then(result => this.setState({ billboards: result, billboardLoading: false }));
    }

    refreshData(isSelfConfigured) {
        const { configuration, previousConfiguration, heatmapData, billboards } = this.state;

        if (_.isEqual(configuration, previousConfiguration) && !isSelfConfigured) {
            return
        }

        this.setState({ dataLoading: true });

        let request = { ...configuration };

        if (isSelfConfigured) {
            request = { ...request, positions: heatmapData, billboards }
        }


        fetch(`${API_URL}/heatmap-data`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ...request })
        })
            .then((response) => response.json())
            .then(result => this.setState({
                previousConfiguration: { ...configuration },
                heatmapData: result.positions,
                billboards: result.billboards,
                monthlyReach: result.monthlyReach,
                totalReach: result.totalReach,
                dataLoading: false,
                activeBillboards: result.activeBillboards
            }));
    }

    setBillboard(index) {
        const { billboards, selectedBillboard } = this.state;

        if (index === selectedBillboard) this.setState({ selectedBillboard: null });

        billboards[index] = { ...billboards[index], active: !billboards[index].active };

        this.setState({ billboards }, () => this.refreshData(true));
    }

    selectBillboard(index) {
        this.setState({ selectedBillboard: index })

    }

    onTransportChange(type) {
        const { configuration } = this.state;

        this.setState({ configuration: { ...configuration, transportType: type } }, () => this.refreshData(false))
    }

    onOccupationChange(type) {
        const { configuration } = this.state;

        this.setState({ configuration: { ...configuration, occupationType: type } }, () => this.refreshData(false))
    }

    onAgeRangeChange({ min, max }) {
        const { configuration } = this.state;

        this.setState({
            configuration: {
                ...configuration,
                minAge: min,
                maxAge: max
            }
        });
    };

    openBillboardDetails(index) {
        const { openedBillboardDetails } = this.state;

        if (index === openedBillboardDetails) {
            this.setState({ openedBillboardDetails: null })
        }
        else {
            this.setState({ openedBillboardDetails: index })
        }

    }

    render() {
        const { heatmapData, dataLoading, billboards, selectedBillboard, configuration, openedBillboardDetails, monthlyReach, activeBillboards, totalReach, helpModelOpen } = this.state;

        const { minAge, maxAge, transportType, occupationType } = configuration;

        return (
            <>
                <Modal
                    show={helpModelOpen}
                    onHide={() => this.setState({helpModelOpen: false})}
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    size="lg"
                >
                    <Modal.Body >
                        <h4 className={styles.title} style={{marginBottom: 30}}>Welcome to Adsnap!</h4>
                        <p className={styles.modalDescription}>A data-driven outdoor advertising platform for smart cities. Here is how you can start benefit from our service:</p>

                        <h2 className={styles.titleNumber}>1.</h2>
                        <p className={styles.modalDescription}>Create you campaign for outdoor advertisement by selecting a target audience of age, transportation method or occupation.</p>

                        <h2 className={styles.titleNumber}>2.</h2>
                        <p className={styles.modalDescription}>Explore our personalised recommendation of the best billboards. Look at the heatmap to understand the location and movement of your customers.</p>
                        <p className={styles.modalDescription}>The billboards are visualised with the markers on the heatmap. Currently selected ones are displayed with blue, while all the others remain gray.</p>

                        <h2 className={styles.titleNumber}>3.</h2>
                        <p className={styles.modalDescription}>Customise your campaign. Add or remove your choice of billboards by clicking on the markers and see the predicted traction and cost of the campaign instantly.
                            You can also find a list of all the selected billboards with some extra information on them.
                        </p>

                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={() => this.setState({helpModelOpen: false})}>Let's get started</Button>
                    </Modal.Footer>
                </Modal>
                <Navbar bg="dark" fixed="top">
                    <Navbar.Brand href="#home">
                        <img
                            src={logoIcon}
                            width="100"
                            className="d-inline-block align-top"
                            alt="Ad Snap logo"
                        />
                    </Navbar.Brand>
                </Navbar>
                <Row>
                    <Col xs={12} sm={12} md={6} lg={6} className={styles.leftColumn}>
                        <Row>
                            <Col xs={12}>
                                <h4 className={styles.title}>Campaign Configuration</h4>
                                <p className={styles.description}>Select your audience inside Helsinki. Based on the
                                    targeted customer segment, we will find the best places for your advertisements.</p>
                            </Col>
                        </Row>
                        <Row>

                            <Col xs={12} sm={12} md={4} lg={4}>
                                <h6>Transportation</h6>
                                <p className={styles.descriptionSmall}>How is your audience moving around?</p>
                                <ButtonGroup size="md" vertical>
                                    <Button variant={transportType === PUBLIC_TRANSPORT ? 'primary' : 'secondary'}
                                            onClick={() => this.onTransportChange(PUBLIC_TRANSPORT)}
                                            disabled={dataLoading}>Public
                                        Transport</Button>
                                    <Button variant={transportType === CAR ? 'primary' : 'secondary'}
                                            onClick={() => this.onTransportChange(CAR)}
                                            disabled={dataLoading}>Car</Button>
                                    <Button variant={transportType === CYCLING ? 'primary' : 'secondary'}
                                            onClick={() => this.onTransportChange(CYCLING)}
                                            disabled={dataLoading}>Cycling</Button>
                                </ButtonGroup>
                            </Col>
                            <Col xs={12} sm={12} md={4} lg={4}>
                                <h6>Occupation</h6>
                                <p className={styles.descriptionSmall}>Why is your audience in Helsinki?</p>
                                <ButtonGroup size="md" vertical>
                                    <Button variant={occupationType === RESIDENT ? 'primary' : 'secondary'}
                                            onClick={() => this.onOccupationChange(RESIDENT)}
                                            disabled={dataLoading}>Resident</Button>
                                    <Button variant={occupationType === TOURIST ? 'primary' : 'secondary'}
                                            onClick={() => this.onOccupationChange(TOURIST)}
                                            disabled={dataLoading}>Tourist</Button>
                                </ButtonGroup>
                            </Col>
                            <Col xs={12} sm={12} md={4} lg={4}>
                                <h6>Age</h6>
                                <p className={styles.descriptionSmall}>What is the age of your audience? This works only for local residents.</p>
                                <div style={{ marginTop: 35 }}>
                                    <InputRange
                                        maxValue={95}
                                        minValue={1}
                                        step={1}
                                        value={{ min: minAge, max: maxAge }}
                                        disabled={dataLoading || occupationType === TOURIST}
                                        onChange={this.onAgeRangeChange}
                                        onChangeComplete={() => occupationType === RESIDENT && this.refreshData(false)}
                                    />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12}>
                                <h4 className={styles.title} style={{ marginTop: 80 }}>Campaign Plan & Prediction</h4>
                                <p className={styles.description} style={{ marginBottom: 6 }}>This campaign is
                                    personalized just for you! Look at
                                    the map to see the most common locations of your audience members.</p>

                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={12} md={4} lg={4}>
                                <CounterWithLabel value={activeBillboards || 0} label="Selected billboards" />
                            </Col>
                            <Col xs={12} sm={12} md={4} lg={4}>
                                <CounterWithLabel value={totalReach || 0} label="Monthly view" />
                            </Col>
                            <Col xs={12} sm={12} md={4} lg={4}>
                                <CounterWithLabel value={totalReach * 0.52 || 0} label="Campaign value" postfix="€" />
                            </Col>
                        </Row>
                        {monthlyReach && (
                            <Row>
                                <Col xs={12}>
                                    <div className={styles.monthlyViews}>
                                        <ResponsiveContainer width="100%" height={140}>
                                            <BarChart data={serialiseData(monthlyReach)}>
                                                <XAxis dataKey="day" interval={0} tick={renderCustomAxisTick} />
                                                <Bar dataKey="value" stroke="#0029FF" fillOpacity={1} fill="#0029FF" />
                                            </BarChart>
                                        </ResponsiveContainer>
                                        <div className={styles.chartLabel}>Traction during the month</div>
                                    </div>
                                </Col></Row>

                        )
                        }
                        <Row>
                            <Col xs={12}>
                                <h4 className={styles.title}>Selected Billboards</h4>
                                <p className={styles.description}> We also hand picked the best available
                                    billboards for the campaign. Have a better idea? Feel free to customize everything
                                    by yourselves! Click the markers on the map to add or remove a billboard.
                                </p>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12}>
                                <ActiveBillboardList billboards={billboards}
                                                     selectBillboard={this.selectBillboard}
                                                     selectedBillboard={selectedBillboard}
                                                     openBillboardDetails={this.openBillboardDetails}
                                                     openedBillboardDetails={openedBillboardDetails} />
                            </Col>
                        </Row>

                    </Col>
                    <Col xs={12} sm={12} md={6} lg={6} className={styles.rightColumn}>
                        {(dataLoading) &&
                        <div className={styles.loaderContainer}><BounceLoader color="#0029FF" /></div>}
                        <Heatmap
                            positions={heatmapData || []}
                            billboards={billboards || []}
                            setBillboard={this.setBillboard}
                            selectedBillboard={selectedBillboard}
                            radius={20}
                            opacity={0.6} />
                    </Col>
                </Row>

            </>
        );
    }
}

export default NewAdPage;
