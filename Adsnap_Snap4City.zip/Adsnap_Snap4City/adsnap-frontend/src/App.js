import React, { Component } from 'react';

import NewAdPage from './page/NewAdPage';
import styles from './App.module.sass'


class App extends Component {
  render() {
    return (
      <NewAdPage />
    );
  }
}

export default App;
